<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class User extends MY_Controller {

	
	public function __construct()
	{
	    parent::__construct();
	    $this->load->helper('api');
	    $this->load->model('UserModel');
	}

	
	public function registerPhone()
	{

		
		if($this->input->method()=='post') {
			$this->form_validation->set_rules('phone', 'Phone', 'trim|required|is_unique[users.phone]');
			$this->form_validation->set_message('is_unique', 'The phone is already taken');
			if ($this->form_validation->run() == true) {
				$phone= $this->input->post('phone');
				$otp = generate_otp();
				$data = array(
					'phone'=>$phone,
					'body' =>"Your one time password is ".$otp
				);
				//$sms_response = send_sms($data);
				$register_data = array(
					'phone'=>$phone,
					'otp' => $otp,
					'created_at' => date("Y-m-d H:m:s")
				);
				$user_id = $this->UserModel->insert($register_data);
				if($user_id){
					$user= $this->UserModel->get(array('id'=>$user_id));
					if($user){
						$response= array("status"=>true,'message'=>"Record inserted successfully!",'user'=>$user);
					}
				}
			}else{
				$errors = $this->form_validation->error_array();
				$response = array('status'=>false,'errors'=>$errors);
			}

			$this->data= $response;
			$this->renderJson($this->data);
		}
	}// end of registerPhone method

	public function otpVerify()
	{
		if($this->input->method()=='post') {
		   $this->form_validation->set_rules('user_id', 'User id', 'trim|required');
		   $this->form_validation->set_rules('device_type', 'Device type', 'trim|required');
		   $this->form_validation->set_rules('device_id', 'Device id', 'trim|required');
		   $this->form_validation->set_rules('otp', 'OTP', 'trim|required');
		   if ($this->form_validation->run() == true){
		   		$user_id = $this->input->post('user_id');
		   		$otp = $this->input->post('otp');
		   		

		   	   $is_verified = $this->UserModel->verifyOtp(array('user_id'=>$user_id,'otp'=>$otp));
		   	   if($is_verified){
		   	   		$update_data = array(
			   			'device_type' => $this->input->post('device_type'),
			   			'device_id'=>$this->input->post('device_id'),
			   			'otp_verify'=>1
			   		);
		   	   		$this->UserModel->update($update_data,array('id'=>$user_id));
		   	   		$user = $this->UserModel->get(array('id'=>$user_id));
		   	   		$response = array('status'=>true,'message'=>'OTP verified successfully','user'=>$user);
		   	   }else{

		   	   		$response = array('status'=>false,'errors'=>array('otp'=>'OTP code doesn\'t match'));

		   	   }

		   }else{

		   		$errors = $this->form_validation->error_array();
				$response = array('status'=>false,'errors'=>$errors);
		   }

		   $this->data= $response;
		   $this->renderJson($this->data);

		}
	}// end of otpVerify method

	public function register() {

		if($this->input->method()=='post') {
			$this->form_validation->set_rules('username', 'Username', 'trim|required|is_unique[users.username]');
		   $this->form_validation->set_rules('email', 'Email', 'trim|required|is_unique[users.email]|valid_email');
		   $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
		   $this->form_validation->set_rules('user_id', 'User id', 'trim|required');
		   if ($this->form_validation->run() == true){

		   }else{
		   	
		   		$errors = $this->form_validation->error_array();
				$response = array('status'=>false,'errors'=>$errors);
		   }
		   $this->data= $response;
		   $this->renderJson($this->data);
		}

	}// end of register method

}// end of class
